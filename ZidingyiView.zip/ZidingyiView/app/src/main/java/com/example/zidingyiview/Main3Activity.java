package com.example.zidingyiview;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;



import com.example.zidingyiview.View.ChartView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;


public class Main3Activity extends AppCompatActivity {

  //  private EditText BarEditText1;
  //  private Button btn;
    private ChartView mChartView;
    int a = 1,b = 1,c = 1,d = 1,e = 1,f = 1,g = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);



        GetByHttpClient();


         mChartView = findViewById(R.id.chartview);

         int[][] columnInfo = new int[][]{
                {a, Color.parseColor("#FFA500")},
                {b, Color.parseColor("#FFD700")},
                {c, Color.parseColor("#BC8F8F")},
                {d, Color.parseColor("#DB7093")},
                {e, Color.parseColor("#FFA500")},
                {f, Color.parseColor("#DAA520")},
                {g, Color.parseColor("#9932CC")},
        };

        mChartView.setColumnInfo(columnInfo);
        mChartView.setAxisDividedSizeX(10);
        mChartView.setAxisDividedSizeY(10);

    }

    public void GetByHttpClient(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    HttpClient httpclient = new DefaultHttpClient();
                    HttpPost httpPost = new HttpPost("Http://2399s482t3.zicp.vip/AndroidWeb/GetTeamData");
                    final UrlEncodedFormEntity entity = null;
                    httpPost.setEntity(entity);
                    HttpResponse httpResponse = httpclient.execute(httpPost);
                    if (httpResponse.getStatusLine().getStatusCode()==200)
                    {
                        HttpEntity entity1 = httpResponse.getEntity();



                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }



}














































