package com.example.zidingyiview;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.zidingyiview.View.TitleView;


public class MainActivity extends AppCompatActivity {

    private TitleView mTitleBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        mTitleBar = (TitleView) findViewById(R.id.title_bar);
        mTitleBar.setLeftButtonListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "点击了返回按钮", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    public void gotomain2Click(View view){
        Intent intent = new Intent();
        intent.setClass(MainActivity.this,Main2Activity.class);
        startActivity(intent);
    }

    public void gotomain3Click(View view){
        Intent intent = new Intent();
        intent.setClass(MainActivity.this,Main3Activity.class);
        startActivity(intent);
    }

    public void gotomain4Click(View view){
        Intent intent = new Intent();
        intent.setClass(MainActivity.this,Main4Activity.class);
        startActivity(intent);
    }

    public void gotomain5Click(View view){
        Intent intent = new Intent();
        intent.setClass(MainActivity.this,Main5Activity.class);
        startActivity(intent);
    }

}