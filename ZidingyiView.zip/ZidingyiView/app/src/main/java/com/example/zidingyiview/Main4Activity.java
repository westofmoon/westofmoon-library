package com.example.zidingyiview;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;

import com.example.zidingyiview.Bean.RoseBean;

import com.example.zidingyiview.Bean.PieChartBean;
import com.example.zidingyiview.View.PolygonsView;
import com.openxu.cview.chart.barchart.BarVerticalChart;
import com.openxu.cview.chart.bean.BarBean;
import com.openxu.cview.chart.bean.ChartLable;
import com.openxu.cview.chart.piechart.PieChartLayout;
import com.openxu.cview.chart.rosechart.NightingaleRoseChart;
import com.openxu.utils.DensityUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main4Activity extends AppCompatActivity  implements SeekBar.OnSeekBarChangeListener{

    PolygonsView mv;
    SeekBar sb1, sb2, sb3, sb4, sb5, sb6, sb7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);


        //NightingaleRoseChart
        NightingaleRoseChart roseChartSmall = (NightingaleRoseChart)findViewById(R.id.roseChartSmall);
        roseChartSmall.setShowChartLable(true);    //是否在图表上显示指示lable
        roseChartSmall.setShowChartNum(false);     //是否在图表上显示指示num
        roseChartSmall.setShowNumTouched(false);   //点击显示数量
        roseChartSmall.setShowRightNum(true);      //右侧显示数量
        List<Object> roseList = new ArrayList<>();
        roseList.add(new RoseBean(10, "数据1"));
        roseList.add(new RoseBean(13, "数据2"));
        roseList.add(new RoseBean(31, "数据3"));
        roseList.add(new RoseBean(8, "数据4"));
        roseList.add(new RoseBean(21, "数据5"));
//参数1：数据对象class， 参数2：数量属性字段名称， 参数3：名称属性字段名称， 参数4：数据集合
        roseChartSmall.setData(RoseBean.class, "count", "ClassName", roseList);
        roseChartSmall.setLoading(false);//是否正在加载，数据加载完毕后置为false


        //PieChartLayout
        PieChartLayout pieChart1 = (PieChartLayout)findViewById(R.id.pieChart1);
        /*
         * 圆环宽度
         * ringWidth > 0 :空心圆环，内环为白色，可以在内环中绘制字
         * ringWidth <=0 :实心
         */
        pieChart1.setRingWidth(DensityUtil.dip2px(this, 25));
        pieChart1.setLineLenth(DensityUtil.dip2px(this, 8)); // //指示线长度
        pieChart1.setTagModul(PieChartLayout.TAG_MODUL.MODUL_CHART);       //在扇形图上显示tag
        pieChart1.setDebug(false);
        pieChart1.setLoading(true);
//请求数据
        List<PieChartBean> datalist = new ArrayList<>();
        datalist.add(new PieChartBean(10, "数据1"));
        datalist.add(new PieChartBean(13, "数据2"));
        datalist.add(new PieChartBean(31, "数据3"));
        datalist.add(new PieChartBean(8, "数据4"));
        datalist.add(new PieChartBean(5, "数据5"));
//显示在中间的lable
        List<ChartLable> tableList = new ArrayList<>();
        tableList.add(new ChartLable("建筑", DensityUtil.sp2px(this, 12), getResources().getColor(R.color.text_color_light_gray)));
        tableList.add(new ChartLable("性质", DensityUtil.sp2px(this, 12), getResources().getColor(R.color.text_color_light_gray)));
        pieChart1.setLoading(false);
//参数1：数据类型   参数2：数量字段名称   参数3：名称字段   参数4：数据集合   参数5:lable集合
        pieChart1.setChartData(PieChartBean.class, "Numner", "Name",datalist ,tableList);



        //VerticaBarActivity
        BarVerticalChart chart1 = (BarVerticalChart)findViewById(R.id.chart1);
        chart1.setBarSpace(DensityUtil.dip2px(this, 1));  //双柱间距
        chart1.setBarItemSpace(DensityUtil.dip2px(this, 20));  //柱间距
        chart1.setDebug(false);
        chart1.setBarNum(2);   //一组柱子数量
        chart1.setBarColor(new int[]{Color.parseColor("#5F93E7"),Color.parseColor("#F28D02")});
//X轴
        List<String> strXList = new ArrayList<>();
//柱状图数据
        List<List<BarBean>> dataList = new ArrayList<>();
        for(int i = 0; i<5; i++){
            //此集合为柱状图上一条数据，集合中包含几个实体就是几个柱子
            List<BarBean> list = new ArrayList<>();
            Random random = new Random();
            list.add(new BarBean(random.nextInt(30), "接入系统"));
            list.add(new BarBean(random.nextInt(20), "审核信息"));
            dataList.add(list);
            strXList.add((i+1)+"月");
        }
        chart1.setLoading(false);
        chart1.setData(dataList, strXList);



        mv = (PolygonsView) findViewById(R.id.mv);
        sb1 = (SeekBar) findViewById(R.id.sb1);
        sb1.setOnSeekBarChangeListener(this);

        sb2 = (SeekBar) findViewById(R.id.sb2);
        sb2.setOnSeekBarChangeListener(this);

        sb3 = (SeekBar) findViewById(R.id.sb3);

        sb3.setOnSeekBarChangeListener(this);
        sb4 = (SeekBar) findViewById(R.id.sb4);

        sb4.setOnSeekBarChangeListener(this);
        sb5 = (SeekBar) findViewById(R.id.sb5);

        sb5.setOnSeekBarChangeListener(this);
        sb6 = (SeekBar) findViewById(R.id.sb6);

        sb6.setOnSeekBarChangeListener(this);
        sb7 = (SeekBar) findViewById(R.id.sb7);

        sb7.setOnSeekBarChangeListener(this);


    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        float values = (float) (seekBar.getProgress() / 10.0);
        switch (seekBar.getId()) {
            case R.id.sb1:
                mv.setValue1(values);
                break;
            case R.id.sb2:
                mv.setValue2(values);
                break;
            case R.id.sb3:
                mv.setValue3(values);
                break;
            case R.id.sb4:
                mv.setValue4(values);
                break;
            case R.id.sb5:
                mv.setValue5(values);
                break;
            case R.id.sb6:
                mv.setValue6(values);
                break;
            case R.id.sb7:
                mv.setValue7(values);
                break;
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {


    }
}
