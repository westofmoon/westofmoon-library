package com.example.zidingyiview;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.zidingyiview.View.CircularView;

import java.util.HashMap;

public class Main2Activity extends AppCompatActivity {
    private CircularView mycircularView;
    private HashMap<String , Float> dataDegree = new HashMap<>();
    private HashMap<String , String> dataColor = new HashMap<>();

    private LinearLayout mLny;
    LinearLayout.LayoutParams params;

    private EditText etCanyin, etYule, etChuxing, etShenghuo, etFushi;
    private Button btnUpdate;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        initView();
    }

    private void initView() {
        mLny = findViewById(R.id.lnyOut);
        etCanyin = findViewById(R.id.etCanyin);
        etYule = findViewById(R.id.etWenjiao);
        etChuxing = findViewById(R.id.etChuxing);
        etFushi = findViewById(R.id.etFushi);
        etShenghuo = findViewById(R.id.etShenghuo);

        btnUpdate = findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uodatePieChart();
            }
        });

    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onResume() {
        super.onResume();
        mycircularView = new CircularView(this, DataDegree(), DataColor());
        params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);

        mLny.addView(mycircularView, params);
    }

    private HashMap<String , Float> DataDegree(){
        dataDegree.put("餐饮消费", 0f);
        dataDegree.put("文教娱乐", 0f);
        dataDegree.put("服饰美容", 0f);
        dataDegree.put("出行交通", 0f);
        dataDegree.put("其它方面", 0f);
        return dataDegree;
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    private HashMap<String , String> DataColor(){

        dataColor.put("餐饮消费", "#6600ff");
        dataColor.put("文教娱乐", "#cc00ff");
        dataColor.put("服饰美容","#9933ff");
        dataColor.put("出行交通", "#ff9900");
        dataColor.put("其它方面","#9999ff");
        return dataColor;
    }

    private void uodatePieChart(){

        float canyin = getFloat(etCanyin);
        float yule = getFloat(etYule);
        float shenghuo = getFloat(etShenghuo);
        float chuxing = getFloat(etChuxing);
        float fushi = getFloat(etFushi);

        float total = canyin +yule +fushi +shenghuo +chuxing;

        if(total>0){

            dataDegree.put("餐饮消费", getDegree(canyin,total));
            dataDegree.put("服饰美容", getDegree(fushi,total));
            dataDegree.put("其它方面", getDegree(shenghuo,total));
            dataDegree.put("出行交通", getDegree(chuxing,total));
            dataDegree.put("文教娱乐", getDegree(yule,total));
            mLny.removeView(mycircularView);
            mLny.addView(mycircularView, params);
            Log.i("test draw", "remove view ; add view");
            Toast.makeText(this,"哇，你居然在"+getMaxinumType()+"上花了这么多",Toast.LENGTH_SHORT).show();

        }else {
            Toast.makeText(this,"输入您的消费额度",Toast.LENGTH_SHORT).show();
        }
    }

    private float getDegree(float number, float total){
        return  number/total * 360;
    }

    private float getFloat(EditText editText){
        float mdata = 0f;
        try {
            if(editText.getText().toString().equals("")){
                mdata = (float) Double.parseDouble(editText.getHint().toString());
            }else {
                mdata = (float) Double.parseDouble(editText.getText().toString());
            }
        }catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this,"输入格式错误",Toast.LENGTH_SHORT).show();
        }finally {
            return mdata;
        }
    }

    private String getMaxinumType(){
        String type="";
        float money = Float.MIN_VALUE;
        for(String key : dataDegree.keySet()){
            if(dataDegree.get(key) > money){
                type = key;
                money = dataDegree.get(key);
            }
        }
        return type;
    }
}
